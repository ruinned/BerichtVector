#!/Dwimperl/perl/bin/perl.exe -w
use strict;

use Cwd;
use List::MoreUtils qw(first_index);

# definition of global variables
my $working = cwd();
my $from = $working;
my $Anzahlbytes = -s "$from/test.bin";
my $counter = 0;
my $numParam = 0;
my $dataLogList;
my $element_type;
my $time;
my $element_id_comp;		# eventid is composed of comp and comp
my $element_id_code;		# eventid is composed of comp and code
my $testcase_id;
my $data1;
my $data2;
my $data3;
my $data4;
my $data5;
my $zeilen_binary;
my $controlflow_testcase = 0;
my $testcase_str = chr(hex 'FF');

my @chars;

# main - method
ProcessBinArray();





sub ProcessBinArray
{
	
	# open file in binary mode
	open(LESEN1,"$from/test.bin")
	or die "Fehler beim Oeffnen von 'test.bin': $!\n";
	binmode(LESEN1);
	read(LESEN1, $zeilen_binary, $Anzahlbytes);
	close(LESEN1);
	@chars = split("", $zeilen_binary);
	
	# short the binary array
	$Anzahlbytes = find_EOF(@chars);
	@chars = @chars[0..$Anzahlbytes];

	# open the file to be writen
	open(SCHREIBEN,"> BteReport_Log.xml")
	or die "Fehler beim Oeffnen von 'BteReport_Log.xml': $!\n";		
	
	do
	{
		my @next_array = ReadNext(1);
		if( $next_array[0] eq $testcase_str)
		{
		  ProcessDataTestCase( ReadNext(2) );
		}
		else
		{
			  $numParam = GetDynLngth(@next_array);
			  ProcessEvent( ReadNext( 6 + 4*$numParam ) );			
		}
		
	} while($counter < $Anzahlbytes);
	
	# after the analysis of the file the last tree can be closed
	if($controlflow_testcase == 1)	
	{
     	CloseTestcase();
	}
	
	# close the file that was writen 
	close(SCHREIBEN) or die "Fehler beim Schliessen von 'BteReport_Log.xml': $! \n";
}

sub ProcessDataTestCase(@)
{
	my @datatestcaseid = @_;	
	
	# analyse test case id
	$testcase_id = process16(@datatestcaseid);			
	
	# After the processing of the information, it can be printed out
	if($controlflow_testcase == 1)
	{ 
		# close tastcase 					
		CloseTestcase();				
	}
	# open testcase
	OpenTestcase($testcase_id);

}

sub GetDynLngth(@)
{	
	# Event type und Anzahl uebergebener Parameter werden analysiert
	my @nP_T_LogList = @_;
	my $returnnumParam = (atoi($nP_T_LogList[0]) & hex('f0'))>>4;
	$element_type = atoi($nP_T_LogList[0]) & hex('f');
	
	return $returnnumParam;
}

sub ProcessEvent(@)
{
	my @dataevent = @_;
	
	# analyse event id
	$element_id_comp = atoi($dataevent[0]);
	$element_id_code = atoi($dataevent[1]);
	
	# analyse time information	
	$time = process32(@dataevent[2..5]);	
	
	print SCHREIBEN "<Element type=\"$element_type\" time=\"$time\">$element_id_comp$element_id_code";
	print "<Element type=\"$element_type\" time=\"$time\">$element_id_comp$element_id_code";			
	
	if ($numParam >= 1)
	{
		$data1 = process32(@dataevent[6..9]);
		print SCHREIBEN " data1=$data1";
		print " data1=$data1";
		
		if ($numParam >= 2)
		{		
			$data2 = process32(@dataevent[10..13]);
			print SCHREIBEN " data2=$data2";
			print " data2=$data2";	
				
			if ($numParam >= 3)
			{
				$data3 = process32(@dataevent[14..17]);
				print SCHREIBEN " data3=$data3";
				print " data3=$data3";
				
				if ($numParam >= 4) 
				{
					$data4 = process32(@dataevent[18..21]);
					print SCHREIBEN " data4=$data4";			
					print " data4=$data4";
					
					if ($numParam == 5)
					{
						$data5 = process32(@dataevent[22..25]);
						print SCHREIBEN " data5=$data5";
						print " data5=$data5";
											
					}							
				}		
			}	
		}			
	}	
			
	print SCHREIBEN "</Element>\n";
	print "</Element>\n";
}

sub OpenTestcase($)
{
	print "<testcase id=\"$testcase_id\">\n";
	print "<testrun date=\"".localtime."\" executor=\"".getlogin."\"parameter=\"\">\n";
	print "<log>\n";
	print SCHREIBEN "<testcase id=\"$testcase_id\">\n";
	print SCHREIBEN "<testrun date=\"".localtime."\" executor=\"".getlogin."\"parameter=\"\">\n";
	print SCHREIBEN "<log>\n";		
	$controlflow_testcase = 1;
}

sub CloseTestcase()
{
	print "<\/log>\n";			
	print "<\/testrun>\n";
	print "<\/testcase>\n";
	print SCHREIBEN "<\/log>\n";			
	print SCHREIBEN "<\/testrun>\n";
	print SCHREIBEN "<\/testcase>\n";
	$controlflow_testcase = 0;
}

sub ReadNext($)
{
	my @array2return = @chars[$counter..($counter + $_[0]-1)];
	$counter += $_[0];
	return @array2return;
}

sub process32(@)
{
	my $var = 0;
	my @loc_arr = @_;	
	
	$var |= atoi($loc_arr[0]) << 24;	
	$var |= atoi($loc_arr[1]) << 16;
	$var |= atoi($loc_arr[2]) << 8;
	$var |= atoi($loc_arr[3]);	
	
	return $var;
}

sub process16(@)
{
	my $var = 0;
	my @loc_arr = @_;		
	
	$var |= atoi($loc_arr[0]) << 8;
	$var |= atoi($loc_arr[1]); 
	
	return $var;
}

sub atoi($)
{
#	my $h1 = unpack('H*',$loc_arr[0]); # char to corresponding ascii hex numb
#	my $h2 = hex($h1);	# hex to decimal number 
	return hex(unpack('H*',$_[0]));	
}

sub find_EOF(@)
 {
 	my @loc_array = @_;
 	my $index_slash = first_index { $_ eq '\\' } @loc_array;
 	my $index_n = first_index { $_ eq 'n' } @loc_array;
 	
 	return $index_n - 2; 	
 	
 }

